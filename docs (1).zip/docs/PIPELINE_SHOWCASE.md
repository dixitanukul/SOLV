# ⚙️ The Contract Intelligence Pipeline
## A Single Revolutionary Data Product That Transforms How an Entire Organization Deals With Provider Contracts

---

## The Vision: Global Contract Intelligence

> *"We have received interest from the Network team with a more ambitious goal of **Global Contract Intelligence**. They want to create a standardized set of contract attributes that can be digitized once and then reused across Utilization Management, Care Management, Provider Relations, Analytics, and other downstream functions."*
> 
> — Stakeholder Communication, Health Plan Ops Transformation

This is the pipeline that makes that vision real. **Digitize once. Reuse everywhere. Trust completely.**

---

## What This Pipeline Does

It takes **30,000+ raw contract PDFs** — unstructured, chaotic, spanning 20+ years of amendments and versions — and transforms them into a **unified, queryable, always-current knowledge system** backed by a star-schema data model with 45 Delta Lake tables, a vector search index, and a citation-verified retrieval engine.

```
┌───────────────────────────────────────────────────────────────────────┐
│  30,000+ Raw PDFs (78 GB, 1.2M pages)                           │
│  Unstructured • Multi-version • Chaotic naming • No metadata      │
└─────────────────────────────────┴─────────────────────────────────────┘
                                │
                    ┌─────────────┴─────────────┐
                    │ CIP v5 DATA PIPELINE  │
                    │ (16 orchestrated      │
                    │  Databricks notebooks)│
                    └─────────────┴─────────────┘
                                │
┌─────────────────────────────────┴─────────────────────────────────────┐
│  45-Table Star Schema (Unity Catalog)                           │
│  Structured • Versioned • Cited • Queryable • Trusted            │
│  + Vector Search Index + Supersession Graph + Semantic Layer    │
└───────────────────────────────────────────────────────────────────────┘
```

---

## The Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|--------|
| **Compute** | Databricks (Apache Spark) | Distributed processing across cluster |
| **Storage** | Delta Lake (Unity Catalog) | ACID transactions, time-travel, schema enforcement |
| **File Ingestion** | Auto Loader (cloudFiles) | Exactly-once incremental file detection |
| **OCR** | PyMuPDF (fitz) via `mapInPandas` | Distributed PDF text extraction across Spark executors |
| **AI Extraction** | Claude Sonnet 4.5 (Databricks Foundation Model API) | Structured data extraction with 17-rule prompt system |
| **Embeddings** | databricks-gte-large-en (1024d) | Legal-domain semantic embeddings |
| **Vector Search** | Databricks Vector Search | Hybrid retrieval (semantic + lexical + metadata + structural) |
| **Data Model** | Star Schema (45 Delta tables) | Rate rules, clauses, stop-loss, carve-outs, compliance, definitions |
| **Governance** | LLM Audit Trail + Prompt Registry | Full lineage: every AI decision traceable to source page |
| **Quality** | 5-Gate Validation Framework | OCR → LLM → Data Integrity → State → Retrieval quality gates |
| **Testing** | Automated Regression Suite | Schema, row count, FK integrity, value range, cross-stage reconciliation |
| **Observability** | Pipeline Telemetry + Cost Tracking | Per-run cost, latency, error categorization, budget caps |

---

## The 16 Pipeline Stages

### Phase 1: Foundation

| Stage | Notebook | What It Does |
|-------|----------|-------------|
| 01 | `01_config` | Unified configuration: catalog/schema, model endpoints, validation thresholds, feature flags, 45 table constants, telemetry, cost tracking |
| 02 | `02_ddl_setup` | Creates/upgrades all 45 Delta tables with schema evolution support |

### Phase 2: Ingestion & Extraction

| Stage | Notebook | What It Does |
|-------|----------|-------------|
| 03 | `03_file_discovery` | Auto Loader detects new PDFs with exactly-once semantics. Parses filenames to extract provider_id, contract_id, doc_type, version, amendment_order. MD5 hash for change detection. Marks older versions as SUPERSEDED. |
| 04 | `04_ocr_extraction` | Spark-distributed OCR via PyMuPDF. Reads PDFs as binary, distributes across executors via `mapInPandas`. Per-page metrics (word count, confidence). **Gate 1** rejects low-quality extractions before LLM stage. |
| 05 | `05_llm_structured_extraction` | Claude Sonnet 4.5 extracts structured JSON from OCR text. 17-rule prompt system with doc-type-specific instructions. Extracts: rates, clauses, stop-loss, carve-outs, quality incentives, compliance, definitions. Page-level citations for every extracted value. **Gate 2** validates JSON schema conformance. |

### Phase 3: Transform & Model

| Stage | Notebook | What It Does |
|-------|----------|-------------|
| 06 | `06_transform_load` | Parses LLM JSON into star-schema Delta tables. Rate domain normalization (60+ regex rules map inconsistent labels to canonical domains). **Gate 3** checks data integrity: row drops, null rates, date ranges. |
| 07 | `07_state_engine` | Builds the contract state model: document registry, contract hierarchy (base → amendment chain), amendment timeline, **supersession graph** (which versions replace which), provider profiles. |
| 08 | `08_semantic_layer` | Transforms extraction tables into semantic legal units for Vector Search. Unit types: RATE_TABLE, CLAUSE, STOP_LOSS, CARVE_OUT, METADATA, DEFINITION. Each unit is one retrievable concept. |

### Phase 4: Intelligence & Retrieval

| Stage | Notebook | What It Does |
|-------|----------|-------------|
| 09 | `09_intelligence` | Advanced analytics: rate comparison across providers, amendment impact scoring, contract risk assessment, expiration forecasting |
| 10 | `10_retrieval_engine` | **4-Channel Hybrid Retrieval with Reciprocal Rank Fusion (RRF, k=60)**: Semantic (Vector Search), Lexical (ILIKE), Metadata (SQL), Structural (same-doc expansion). Answers questions with multi-source evidence. |
| 11 | `11_citation_verification` | Post-retrieval verification layer: Supersession Risk (is cited doc current?), Grounding Verification (does answer exist in source?), Numerical Accuracy (do dollar amounts match?), Temporal Validity (is info from current version?) |

### Phase 5: Trust & Governance

| Stage | Notebook | What It Does |
|-------|----------|-------------|
| 12 | `12_governance` | LLM audit trail (every call logged with I/O, cost, latency), versioned prompt registry, access control logging, PII detection |
| 13 | `13_observability` | Pipeline telemetry: per-stage duration, throughput, error rates. Cost tracking per run. Budget enforcement. |
| 14 | `14_recovery` | Automatic retry with degradation: SIMPLE → REDUCED → SEQUENTIAL → SKIP. Error categorization: TRANSIENT, CONTENT, SCHEMA, BUDGET, INFRA, UNKNOWN. Resume from failure point. |
| 15 | `15_regression_tests` | Automated assertions on every run: schema tests, row count bounds, referential integrity, value constraints, cross-stage reconciliation. Pipeline halts if quality degrades. |
| 16 | `16_orchestrator` | End-to-end execution coordinator. Sequential dependency management. Conditional stage skipping. Summary reporting. |

---

## The 5-Gate Quality Framework: How We Achieve 100% Trust

The pipeline will **never produce unvalidated data**. Every piece of information passes through 5 progressive quality gates:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   GATE 1        │ →→→ │   GATE 2        │ →→→ │   GATE 3        │
│   OCR Quality   │     │   LLM Schema    │     │   Data Integrity │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ • Min confidence │     │ • Valid JSON     │     │ • Row reconcile  │
│ • Words/page    │     │ • Schema match   │     │ • No null rates  │
│ • Non-ASCII %   │     │ • Confidence >0  │     │ • Date validity  │
│ • Total words   │     │ • Page citations │     │ • FK integrity   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                     │                     │
        ▼                     ▼                     ▼
┌─────────────────┐     ┌─────────────────┐
│   GATE 4        │ →→→ │   GATE 5        │
│   State Engine  │     │   Retrieval     │
├─────────────────┤     ├─────────────────┤
│ • Supersession  │     │ • Grounding     │
│ • Hierarchy     │     │ • Numerical     │
│ • Timeline      │     │ • Temporal      │
│ • Version chain │     │ • Supersession  │
└─────────────────┘     └─────────────────┘
```

**If any gate fails, the data does not advance.** It is quarantined, categorized, and queued for recovery — never silently passed through.

---

## The Data Model: 45 Tables That Change Everything

### Core Extraction Tables
| Table | Content | Business Value |
|-------|---------|---------------|
| `tbl_cip_rate_rules` | Every reimbursement rate with domain, tier, formula, effective dates | Claims adjudication, rate verification, provider payment accuracy |
| `tbl_cip_contract_clauses` | Every contractual clause with category, verbatim text, page citation | Legal compliance, dispute resolution, termination tracking |
| `tbl_cip_stop_loss` | Stop-loss attachment levels, reimbursement formulas, thresholds | Risk management, outlier case monitoring |
| `tbl_cip_carve_outs` | Services excluded from standard rates | Claims routing, prior-auth workflows |
| `tbl_cip_compliance_tracking` | HIPAA, credentialing, regulatory requirements | Compliance monitoring, audit readiness |
| `tbl_cip_definitions` | Contract-defined terms (Allowed Amount, Hospital Services, etc.) | Consistent interpretation across teams |

### State & Intelligence Tables
| Table | Content | Business Value |
|-------|---------|---------------|
| `tbl_cip_contract_documents` | Unified document view (registry + metadata + OCR stats) | Single source of truth for document inventory |
| `tbl_cip_contract_hierarchy` | Base agreement → amendment chain relationships | Amendment chain traversal |
| `tbl_cip_amendment_timeline` | Chronological amendment history per provider | Temporal reasoning, "what was active on date X?" |
| `fact_cip_supersession` | Version supersession graph (what replaced what) | Prevents citing outdated terms |
| `tbl_cip_contract_registry` | Contract state model (1 row per contract lifecycle) | "What's our current agreement?" answered instantly |
| `tbl_cip_provider_profile` | Provider-level aggregates | Portfolio-wide analytics |
| `tbl_cip_rate_domain_map` | Canonical domain normalization (60+ regex rules) | Consistent rate comparisons across providers |

### Semantic & Retrieval Tables
| Table | Content | Business Value |
|-------|---------|---------------|
| `tbl_cip_legal_units` | Semantic legal units (RATE_TABLE, CLAUSE, STOP_LOSS, CARVE_OUT, METADATA, DEFINITION) | Vector Search source, natural language Q&A |
| `idx_cip_legal_units` | Vector Search index (1024-dim GTE embeddings) | Sub-second semantic retrieval |

### Governance & Operations Tables
| Table | Content | Business Value |
|-------|---------|---------------|
| `tbl_cip_gov_llm_audit` | Every LLM call: input/output tokens, cost, latency, status | Cost tracking, compliance audit trail |
| `tbl_cip_gov_prompt_registry` | Versioned prompt templates | Reproducibility, prompt A/B testing |
| `tbl_cip_pipeline_telemetry` | Per-stage execution metrics | Performance monitoring, SLA tracking |
| `tbl_cip_file_registry` | Processing status for every file | Progress tracking, retry management |

---

## How It Achieves 100% Confidence

### 1. Every Value Has a Citation
Every rate, clause, and date extracted by the LLM includes the **exact page number** from the source document. Nothing is inferred or hallucinated — the prompt system explicitly forbids it with Rule #1: *"Extract ONLY what is explicitly stated in the document. Never infer or hallucinate values."*

### 2. The Supersession Graph Prevents Stale Answers
The State Engine (Stage 07) builds a directed graph (`fact_cip_supersession`) that knows:
- Which document versions replace which
- Which amendments supersede earlier ones
- Which contract lifecycle is currently active

Before ANY answer reaches a user, the Citation Verification layer (Stage 11) checks: *"Is the document I'm citing still current, or has it been superseded?"*

### 3. Numerical Accuracy Cross-Check
Dollar amounts in retrieval answers are cross-referenced against the structured `tbl_cip_rate_rules` table. If the free-text answer says "$1,500 per diem" but the table says $1,400 — the system flags a discrepancy.

### 4. Grounding Verification
Every claim in a generated answer is traced back to verbatim text in the source document. If the system cannot ground a statement in the original text, confidence is reduced and the user is warned.

### 5. Regression Testing on Every Run
Automated assertions run on EVERY pipeline execution:
- Schema completeness (all columns exist with correct types)
- Non-empty tables (no silent data loss)
- Primary key uniqueness (no duplicate records)
- Foreign key integrity (no orphaned references)
- Value range checks (no negative rates, no future dates in the past)
- Cross-stage reconciliation (file count in → file count out)

**The pipeline halts itself if quality degrades.** No bad data reaches downstream consumers.

---

## The Evolution: From v4 to v5

| Capability | v4 (2024) | v4.1 (2025) | v5 (2026) |
|-----------|-----------|-------------|----------|
| Pipeline stages | 20+ files (mixed .py/.ipynb) | 14 notebooks (streamlined) | 16 notebooks (optimized) |
| OCR approach | ThreadPoolExecutor | ThreadPoolExecutor + validation | Spark-distributed `mapInPandas` |
| LLM model | GPT-4 / Claude 3 | Claude Sonnet 4.5 | Claude Sonnet 4.5 (Databricks-native) |
| Extraction rules | Basic prompts | Enhanced prompts | 17-rule system with doc-type specialization |
| Quality gates | Manual checks | 3 validation notebooks | 5-Gate automated framework |
| State engine | Basic version tracking | Timeline + supersession | Full graph: hierarchy + timeline + supersession + registry |
| Retrieval | Single-channel vector search | Vector + metadata | 4-channel hybrid + RRF fusion |
| Citation verification | None | Basic grounding | Supersession + Grounding + Numerical + Temporal |
| Domain normalization | Manual mapping | Rule-based | 60+ regex rules with canonical taxonomy |
| Recovery | Manual re-runs | Basic retry | Adaptive degradation (4 retry levels) |
| Governance | None | Basic audit | Full LLM audit + prompt registry + access logs + PII scan |
| Testing | Manual validation | Spot checks | Automated regression suite (every run) |
| Observability | Logs | Basic telemetry | Full telemetry + cost tracking + budget enforcement |
| Tables | ~10 | ~25 | 45 (complete star schema) |
| Incremental | Full re-run | Partial | True incremental (Auto Loader checkpoint) |

---

## Who This Transforms & What Becomes Possible

### For the Contracting Team

**Before:** Manually reading 109 files to understand Mercy General Hospital's current terms. Days of work for one provider.

**After:** Query the contract registry: `SELECT * FROM tbl_cip_contract_registry WHERE provider_name = 'Mercy General Hospital' AND is_active = true` — instant answer with citation to source document and page.

### For Claims & Utilization Management

**Before:** Claims adjudicators calling the contracting team to verify rates. Backlogs growing while waiting for answers.

**After:** Direct SQL access to `tbl_cip_rate_rules` with effective dates, network tiers, service domains, and dollar amounts. Rate lookup in seconds, not days.

### For Provider Relations

**Before:** Entering renegotiations without knowing current terms. Conceding favorable terms that already exist. Missing termination windows.

**After:** Provider profile dashboards showing complete contract state, amendment history, rate trends, and expiration forecasts. Walk into every negotiation fully informed.

### For Analytics & Data Science

**Before:** No structured contract data existed. Analysis was impossible because the data was locked in PDFs.

**After:** A complete structured dataset enabling:
- Rate benchmarking across 900+ providers
- Amendment velocity analysis (which providers require most changes?)
- Clause similarity clustering (which providers have similar terms?)
- Predictive modeling for contract risk and dispute likelihood
- Network adequacy analysis with actual contracted terms
- Cost forecasting based on rate escalation clauses

### For Care Management

**Before:** No visibility into which services are carved out, what prior-auth requirements exist, or which stop-loss thresholds apply.

**After:** Structured `tbl_cip_carve_outs` and `tbl_cip_stop_loss` tables feed directly into care management workflows, prior-auth rules engines, and utilization review systems.

### For Compliance & Audit

**Before:** Manually pulling documents for CMS audits. Weeks of preparation. Risk of missing documents.

**After:** Complete LLM audit trail, versioned prompt registry, access logs, and compliance tracking tables. Audit-ready at all times. Every data point traceable to source page.

### For Executive Leadership

**Before:** No portfolio-wide view of contractual obligations. Strategic decisions made with incomplete information.

**After:** Real-time dashboards showing:
- Total annual payment obligations by provider tier
- Contracts approaching expiration
- Rate competitiveness analysis
- Amendment burden distribution
- Network coverage gaps

---

## The Technical Innovation

### 4-Channel Hybrid Retrieval with RRF

Most contract Q&A systems use simple vector search. We combine **four retrieval channels** fused with Reciprocal Rank Fusion (k=60):

1. **Semantic Channel** — Vector Search on legal unit embeddings ("What are the cardiac rates?")
2. **Lexical Channel** — ILIKE keyword matching (exact terms: "$1,500 per diem")
3. **Metadata Channel** — Structured SQL filters (provider_id, doc_type, date ranges)
4. **Structural Channel** — Same-document expansion (if one clause is relevant, adjacent clauses may be too)

**Result:** No relevant information is missed, regardless of how the question is phrased.

### Rate Domain Normalization (60+ Rules)

The same service gets labeled differently across thousands of documents:
- "Subacute Care Level I" vs "Inpatient Sub-Acute" vs "Inpatient - Subacute Level I"

Our regex-based normalization engine maps ALL variants to canonical domains, enabling apples-to-apples comparison across 900+ providers.

### Adaptive Error Recovery

When processing 30,000 documents, failures are inevitable. The pipeline doesn't stop or lose progress:

```
SIMPLE retry  →  REDUCED context retry  →  SEQUENTIAL processing  →  SKIP & quarantine
```

Errors are categorized (TRANSIENT, CONTENT, SCHEMA, BUDGET, INFRA) and each category gets appropriate handling. The pipeline always resumes from its last successful checkpoint.

---

## The Business Case: Digitize Once, Reuse Everywhere

```
                    ┌─────────────────────────────────┐
                    │  CONTRACT INTELLIGENCE      │
                    │  DATA PIPELINE               │
                    │  (Process once → 45 tables)   │
                    └────────────────┬────────────────┘
                               │
          ┌──────────────────┼──────────────────┐
          │                  │                  │
    ┌─────┴─────┐  ┌─────┴─────┐  ┌─────┴─────┐
    │ Utilization │  │    Care    │  │  Provider  │
    │ Management  │  │ Management │  │ Relations  │
    └───────────┘  └───────────┘  └───────────┘
          │                  │                  │
    ┌─────┴─────┐  ┌─────┴─────┐  ┌─────┴─────┐
    │ Analytics  │  │  Claims   │  │ Compliance │
    │ & Data Sci │  │ Adjudicat.│  │  & Audit   │
    └───────────┘  └───────────┘  └───────────┘
          │                  │                  │
    ┌─────┴─────┐  ┌─────┴─────┐  ┌─────┴─────┐
    │ Executive  │  │  Network  │  │   Q&A     │
    │ Dashboards │  │ Adequacy  │  │  Chatbot  │
    └───────────┘  └───────────┘  └───────────┘
```

**One pipeline. Nine+ downstream consumers. Zero duplication of effort.**

---

## Key Metrics

| Metric | Value |
|--------|-------|
| Documents processed | 30,000+ |
| Tables in data model | 45 |
| Quality gates | 5 (automated, blocking) |
| Retrieval channels | 4 (hybrid fusion) |
| Rate domain normalization rules | 60+ |
| LLM extraction rules | 17 (doc-type specialized) |
| Pipeline stages | 16 (fully orchestrated) |
| Retry levels | 4 (adaptive degradation) |
| Error categories | 6 (typed recovery) |
| Embedding dimensions | 1024 (GTE-large) |
| Validation thresholds | 25+ (tunable per gate) |
| Pipeline versions shipped | 3 (v4 → v4.1 → v5) |
| Time to answer "What's our rate?" | Seconds (was: days) |
| Downstream consumers enabled | 9+ teams |

---

## The Bottom Line

> **This pipeline is not a tool. It is a new capability for the organization.**

Before this pipeline existed, the knowledge locked in 30,000 provider contracts was accessible only to the handful of people who had spent years reading them. When those people left, the knowledge left with them.

After this pipeline runs:
- Every rate is queryable
- Every clause is searchable
- Every version is tracked
- Every amendment is chained
- Every answer is cited
- Every AI decision is auditable
- Every downstream team can self-serve

**One pipeline run digitizes the institutional knowledge of decades. It creates a shared source of truth that 9+ teams can build upon. It is the foundation of Global Contract Intelligence.**

---

*Pipeline source: `cip_v5_pipeline/` (16 notebooks, Unity Catalog: `dev_adb.cip_v5`)*  
*Last updated: August 2026*