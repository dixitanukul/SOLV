# 🎬 Presentation Content Outline
## Contract Intelligence Platform — 12-Minute Panel Presentation (22 Slides)

---

## SECTION 1: PROBLEM & STAKES (Slides 1–6) — ~2:30
*Goal: Make the judges FEEL the weight of the problem before seeing any solution.*

---

### Slide 1: The $Billion Question No One Could Answer
**Type:** Title slide

**Content:**
- Title: "The $Billion Question No One Could Answer"
- Subtitle: "A Contract Intelligence Platform for Blue Shield of California"
- Your name, role, client: Blue Shield of California
- A single powerful stat in large font: **"10,500+ contracts. 30+ years to read. 8 seconds to answer."**

**Visual:** Dark background, dramatic typography. No clutter.

---

### Slide 2: Blue Shield of California — The Contract Landscape
**Type:** Data showcase

**Content — Key Numbers (large, visual):**

| Metric | Value |
|--------|-------|
| Total Contract Documents | 10,518 |
| Repository Size | 27.3 GB |
| Estimated Total Pages | ~408,000 |
| Unique Provider Entities | 328 |
| Total Amendments Tracked | 6,928 |
| Maximum Files (Single Provider) | 109 (Mercy General Hospital) |

**Visual:** Infographic-style numbers with scaled circles.

---

### Slide 3: The 7 Layers of Complexity
**Type:** Problem depth

**Content — 7 numbered items:**
1. **Version Chaos** — Up to 31 versions of a single document (which one is current?)
2. **Amendment Stacking** — 21 sequential amendments piled on one base agreement
3. **Numbering Resets** — 71 providers have multiple "First Amendment" files
4. **Multiple Identities** — One hospital appears under 9 different folder names
5. **CM vs. Standard** — 1,477 counter-marked versions alongside 5,451 standard
6. **Mixed Formats** — 10,372 PDFs (many scanned), 142 DOCX, spreadsheets, legacy DOC
7. **Temporal Ambiguity** — No metadata tells you what's active TODAY

**Visual:** Vertical layered diagram or stacked cards.

---

### Slide 4: The Human Reality — What Happens Today
**Type:** Emotional storytelling

**Content — Timeline:**
```
09:00  Claims team asks: "What's the inpatient rate for Stanford?"
09:30  Analyst opens 72-page PDF, finds rate — "subject to amendment"
10:00  Reads amendments: Third, Seventh, Eleventh...
10:45  Two versions exist (CM and standard). Which was executed?
11:00  Calls contracting manager. Voicemail.
12:00  Emails answer. No citation. No audit trail. Low confidence.

Total: 3 HOURS. 1 phone call. 0 audit trail.
```

**Visual:** Timeline graphic with pain points highlighted in red.

---

### Slide 5: The Cost of Inaction — $5.3M–$15M in Annual Risk
**Type:** Financial shock

**Content:**

| Risk | Annual Exposure |
|------|----------------|
| Claims paid on superseded rates | $3M–$5M |
| Missed termination/renewal windows | $1M–$4M |
| CMS audit findings | $500K–$2M |
| Provider dispute arbitration | $600K–$3M |
| Incorrect network adequacy filings | $200K–$1M |
| **TOTAL ANNUAL RISK** | **$5.3M–$15M** |

---

### Slide 6: The Deep Dive — Mercy General Hospital
**Type:** Case study (jaw-drop moment)

**Content:**
- **109 files. 66 sub-contract IDs. 4 separate base agreements. 256 MB. One single provider.**
- 4 parallel contract lifecycles
- Amendment chains up to 26th
- Two parallel CM/standard chains
- Misspelled amendments (`FifthteenthAmend`)
- **1,040+ combinatorial interpretation paths**

**Visual:** Tree/graph diagram showing the 4 base agreements branching into chains.

---

## SECTION 2: TECHNOLOGY & SOLUTION (Slides 7–14) — ~4:30
*Goal: Show the technology depth. Make judges see this is cutting-edge engineering on a world-class platform.*

---

### Slide 7: The Vision — Global Contract Intelligence
**Type:** Vision / transition

**Content:**
- Stakeholder quote:
  > *"They want to create a standardized set of contract attributes that can be digitized once and then reused across Utilization Management, Care Management, Provider Relations, Analytics, and other downstream functions."*

- Slogan: **"Digitize once. Reuse everywhere. Trust completely."**

---

### Slide 8: Databricks Pipeline Architecture — The Tech Foundation
**Type:** Technology architecture

**Content — 16-stage pipeline on Databricks:**

| Layer | Technology | What It Does |
|-------|-----------|--------------|
| **Ingestion** | Auto Loader (cloudFiles) | Incremental file detection — new PDFs queryable in minutes |
| **Processing** | Apache Spark (distributed) | Parallel OCR + extraction across cluster nodes |
| **LLM Extraction** | `databricks-claude-sonnet-4-5` (Foundation Model API) | 17-rule structured extraction per document |
| **Storage** | Delta Lake (ACID transactions) | 45 managed tables with time travel, schema enforcement |
| **Orchestration** | Databricks Notebooks + Jobs | 16 sequenced stages with checkpointing |
| **Governance** | Unity Catalog (`dev_adb.cip_v5`) | Full lineage, access control, audit trail |

**Key callouts:**
- 📥 Incremental MERGE (exactly-once semantics, no duplicate processing)
- ⚡ Scalable: same pipeline handles 10 docs or 10,000 — just add compute
- 🔄 Reusable: parameterized for any Blue Shield entity (Kansas pilot uses same pipeline)

**Visual:** Horizontal pipeline flow with Databricks logo and technology badges.

---

### Slide 9: Unity Catalog Governance & Data Model
**Type:** Governance + data architecture

**Content — Split layout:**

**Left — Unity Catalog Structure:**
```
Catalog: dev_adb
  Schema: cip_v5
    ├── 45 Delta tables (star schema)
    ├── Vector Search index (idx_cip_legal_units)
    ├── Governance tables:
    │   ├── tbl_cip_gov_llm_audit      (every LLM call logged)
    │   ├── tbl_cip_gov_prompt_registry (versioned prompts)
    │   └── tbl_cip_access_log         (who queried what, when)
    └── Model serving endpoint
```

**Right — 5-Gate Quality Framework:**
1. Gate 1: OCR confidence scoring (reject low-quality extractions)
2. Gate 2: JSON schema validation (LLM output conformance)
3. Gate 3: Data integrity checks (FK constraints, value ranges)
4. Gate 4: State consistency (supersession DAG validation)
5. Gate 5: Retrieval quality (citation verification)

**Governance highlights:**
- Every LLM call: input tokens, output tokens, model version, latency, cost → `tbl_cip_gov_llm_audit`
- Every prompt: versioned, A/B testable, rollback-capable → `tbl_cip_gov_prompt_registry`
- Every user query: timestamped, provider-scoped, exportable → `tbl_cip_access_log`

**Visual:** Unity Catalog tree on left, gate diagram on right.

---

### Slide 10: RAG Architecture & Vector Search
**Type:** Technical depth — retrieval

**Content — 4-Channel Hybrid Retrieval:**

```
User Question
     │
     ▼
┌─────────────────────────────────────────────┐
│  CHANNEL 1: Semantic Search                  │
│  databricks-gte-large-en (1024-dim)          │
│  → Vector Search (idx_cip_legal_units)       │
│  → Cosine similarity, top-k passages        │
├─────────────────────────────────────────────┤
│  CHANNEL 2: Lexical Search (BM25)            │
│  → Keyword matching on contract text         │
├─────────────────────────────────────────────┤
│  CHANNEL 3: Metadata Filtering               │
│  → Provider, contract type, date range       │
│  → current_effective = TRUE filter           │
├─────────────────────────────────────────────┤
│  CHANNEL 4: Structural Retrieval             │
│  → Amendment chain traversal                 │
│  → Supersession graph navigation             │
└─────────────────────────────────────────────┘
     │
     ▼
  Reciprocal Rank Fusion (RRF) → Re-ranked passages → LLM
```

**Key differentiators vs. generic RAG:**
- NOT just "embed and retrieve" — 4 retrieval channels fused
- Supersession-aware: only surfaces CURRENT-EFFECTIVE passages
- Recall boost: detects incomplete retrieval and retries with expanded queries
- Domain-specific chunking: legal units (clauses, sections, exhibits) not arbitrary 512-token blocks

**Visual:** Flow diagram showing 4 channels converging.

---

### Slide 11: Application Architecture & Tech Stack
**Type:** Full-stack showcase

**Content — Layered architecture:**

| Layer | Technology |
|-------|-----------|
| **Frontend** | React 18 + TypeScript + TailwindCSS + Vite |
| **Streaming** | Server-Sent Events (SSE) — real-time token delivery |
| **Backend** | FastAPI (9 endpoints), Python 3.12, async/await |
| **Agent** | ReAct loop (plan → act → observe), max 10 steps |
| **LLM** | `databricks-claude-sonnet-4-5` via Foundation Model API |
| **Embeddings** | `databricks-gte-large-en` (1024 dimensions) |
| **Search** | Databricks Vector Search (idx_cip_legal_units) |
| **Storage** | 45 Delta Lake tables (Unity Catalog managed) |
| **Deployment** | Databricks App (containerized, auto-scaling) |
| **Observability** | Custom telemetry → `tbl_cip_gov_llm_audit` |

**30+ specialized tools:** rate_query, clause_existence, comparison, temporal_analysis, amendment_chain, financial_analysis, risk_alert, provider_scorecard, compliance_query, network_geography, passage_search, chart_generate, export_data...

**Visual:** Vertical stack diagram with technology logos.

---

### Slide 12: LLM-as-Judge & 7-Layer Trust Architecture
**Type:** Validation / differentiation

**Content — 7 layers (bottom to top):**

| Layer | Technique | Cost |
|-------|-----------|------|
| 1. Routing Validation | 6 deterministic override rules (regex + heuristics) | $0 |
| 2. Retrieval Quality | Relevance scoring (threshold: 0.5) + recall boost | $0 |
| 3. Hallucination Guard | 5 checks: numeric, provider identity, date, ungrounded, confidence | $0 |
| 4. Answer Validator ("Prove It") | Detects false absence → runs existence-check SQL → retries | ~$0.002 |
| 5. Grounding Enforcer | Refuses if evidence insufficient (NEVER guesses) | $0 |
| 6. Citation Verifier | Traces every claim → source document + page number | $0 |
| 7. **LLM-as-Judge** | Completeness scoring: did we address ALL sub-questions? | ~$0.003 |

**LLM-as-Judge details:**
- Evaluates answer completeness against decomposed sub-questions
- Scores confidence: HIGH / MODERATE / LOW
- Flags when answer requires human escalation
- Used in pipeline QA: validates LLM extraction quality (Gate 2)

**Key insight:** 5 of 7 layers are ZERO-COST (deterministic). Only 2 use LLM calls (~$0.005 total per query).

**Visual:** Shield/fortress with 7 horizontal bars. Badge: "No other project has even ONE validation layer."

---

### Slide 13: The Range of Questions It Answers
**Type:** Capability showcase

**Content — 8 categories with examples:**

| Category | Example |
|----------|---------|
| **Rate Lookup** | "What's the inpatient per diem rate for Stanford Health Care?" |
| **Clause Existence** | "Does Mercy General have a carve-out for behavioral health?" |
| **Cross-Provider Comparison** | "Compare stop-loss terms for Cedars-Sinai vs. UCLA Medical" |
| **Temporal / Amendment History** | "What was Stanford's rate before the 15th Amendment?" |
| **Portfolio-Wide Analysis** | "Which providers have DRG-based reimbursement?" |
| **Compliance & Risk** | "Any providers with expired contracts still receiving claims?" |
| **Multi-Hop Complex** | "Compare per diem AND stop-loss for top 5 Medi-Cal providers, flag changes in last 12 months" |
| **Financial Impact** | "Total exposure if we lose all per diem contracts above $3,000/day?" |

**Timing:** Simple: 8–12 seconds. Complex multi-hop: 30–60 seconds. All with citations.

---

### Slide 14: Live Demo — Before vs. After
**Type:** Demonstration / comparison

**Content — Split screen:**

**Left (BEFORE): Red-tinted**
```
3 hours | 1 phone call | 0 audit trail | "I think this is right..."
```

**Right (AFTER): Green-tinted**
```
12 seconds | Full citation (doc + page + section) | Confidence: HIGH
"The rate is $2,847/day per the 15th Amendment CM,
 page 4, section 3.2(b). This supersedes $2,614/day
 from the 11th Amendment."
```

**Bottom:** **900x faster. With citations. With confidence. Per query cost: ~$0.01.**

---

## SECTION 3: IMPACT & REVENUE (Slides 15–18) — ~2:00
*Goal: Prove the dollar value.*

---

### Slide 15: Who It Serves — 7+ Business Units
**Type:** Impact breadth

**Content:**

| Team | Before | After |
|------|--------|-------|
| Claims Adjudication | 45-min phone calls | 15-second verified answers |
| Provider Relations | Negotiate blind | Full scorecard before every meeting |
| Utilization Management | Call contracting team | Instant carve-out/stop-loss lookup |
| Network Management | Manual spreadsheets | Natural language coverage queries |
| Analytics | Zero structured data | Rate benchmarking & clause clustering |
| Compliance & Audit | Weeks of prep | Full provenance trail on demand |
| Executive Leadership | Commission multi-week analysis | Instant portfolio visibility |

---

### Slide 16: Validated Business Impact — $690K–$1M/yr
**Type:** Financial proof

**Content:**
- **Client quote:** *"The total potential annual value is estimated at approximately $690,000 to $1 million."* — Blue Shield of California, C-Suite Recognition Letter
- Breakdown: $308K (research) + $54K (onboarding) + $179K (renewals) + $150K–$500K (vendor avoidance)
- **Validation badge:** "Figures written BY the client, not self-reported."

---

### Slide 17: Revenue Generation — Licensing to 35 Blue Shield Plans
**Type:** Revenue / product

**Content:**

| Year | Licensees | Revenue |
|------|-----------|--------|
| Year 1 | 2–3 | $400K–$750K |
| Year 3 | 10–15 | $2.5M–$5M |
| Year 5 | 20+ | $5M–$10M |

- Market: 35 Blue Cross Blue Shield companies, 115M+ members
- First licensee: Blue Shield of Kansas (pilot)
- **"Not a project. A PRODUCT."**

---

### Slide 18: 5-Year Value — $31.7M Total Impact
**Type:** Financial crescendo

**Content:**

| Category | 5-Year Total |
|----------|-------------|
| Internal savings | $4.7M |
| External licensing revenue | $17M |
| Risk mitigation | $10M |
| **TOTAL** | **$31.7M** |

- ROI: 13x Year 1. Payback: <3 months.

---

## SECTION 4: OWNERSHIP & CLOSE (Slides 19–22) — ~1:30
*Goal: Execution credibility and close.*

---

### Slide 19: Delivery Timeline — Concept to Production in 5 Months
**Type:** Execution speed

**Content:**

| Month | What Was Shipped |
|-------|-----------------|
| Apr 2026 | Foundation: corpus analysis, 45-table data model, pipeline architecture |
| May 2026 | Pipeline v4: OCR, LLM extraction, rate normalization (60+ regex rules) |
| Jun 2026 | Pipeline v4.1: state engine, semantic layer, Vector Search, governance |
| Jul 2026 | Application: FastAPI + ReAct agent + 30 tools + React frontend |
| Aug 2026 | v5 pipeline + productization: evaluation harness, Kansas pilot prep |

**Disciplines:** Data Engineering, Data Modeling, NLP/LLM, Retrieval/Search, Trust & Safety, Full-Stack Web, DevOps, Domain Expertise, Product Strategy

---

### Slide 20: The Hardest Problems Solved
**Type:** Engineering credibility

**Content — 3 challenges:**

1. **Supersession Problem** — No system tells you which of 109 documents governs today. Solution: DAG-based state engine resolving amendment chains with `current_effective` computation.

2. **Grounding Paradox** — LLMs hallucinate confidently on financial data. Solution: 7-layer trust with zero-cost numeric verification (`$27,748` vs `27748.0` formatting bug caught in production).

3. **Routing Ambiguity** — "Does Stanford have per diem rates?" = 3 possible question types. Solution: 6 deterministic override rules correcting LLM misclassification.

---

### Slide 21: What's Next — Roadmap
**Type:** Forward-looking

**Content:**
- Q4 2026: Proactive expiration alerts + Blue Shield Kansas live
- Q1 2027: Cross-plan benchmarking + automated renewal briefings
- Q2 2027: 3–5 additional licensees ($750K–$1.25M revenue)
- 2028: 10–15 licensees + commercial payer expansion

---

### Slide 22: The Bottom Line — Why This Wins
**Type:** Closing

**Content — The card:**
```
╔══════════════════════════════════════════════════╗
║  10,500+ docs │ 27 GB │ 408K pages              ║
║  16-stage Databricks pipeline │ 45 Delta tables ║
║  RAG + Vector Search │ LLM-as-Judge │ 7 trust   ║
║                                                  ║
║  $690K–$1M/yr savings (client-validated)         ║
║  $500K–$2M/yr licensing revenue                  ║
║  $5.3M–$15M/yr risk mitigated                   ║
║                                                  ║
║  Concept to production │ 5 months                ║
║  Live users │ Revenue-generating                 ║
║                                                  ║
║  NOT a project. A PRODUCT.                       ║
╚══════════════════════════════════════════════════╝
```

**Closing:** *"The most complex, highest-impact AI platform at LatentView this year. And it's just getting started."*

---

## TIMING BUDGET

| Section | Slides | Time |
|---------|--------|------|
| Problem & Stakes | 1–6 | ~2:30 |
| Technology & Solution | 7–14 | ~4:30 |
| Impact & Revenue | 15–18 | ~2:00 |
| Ownership & Close | 19–22 | ~1:30 |
| Buffer (pauses/transitions) | — | ~1:30 |
| **TOTAL** | **22 slides** | **~12:00** |

---

## Q&A PREPARATION

- "What tech stack?" → Databricks end-to-end: Auto Loader, Spark, Delta Lake, Unity Catalog, Vector Search, Foundation Model API (Claude Sonnet 4.5), Databricks App deployment
- "How do you prevent hallucinations?" → 7-layer trust; 5 layers zero-cost deterministic; LLM-as-Judge for completeness
- "How is this different from generic RAG?" → 4-channel hybrid retrieval, supersession-aware filtering, domain-specific chunking, 30+ specialized tools vs. one retrieval function
- "How do you handle governance?" → Unity Catalog: every LLM call audited, prompts versioned, access logged, full lineage
- "Is it scalable?" → Same pipeline handles 10 or 10,000 docs. Parameterized for any Blue Shield entity. Kansas pilot uses identical infrastructure.
- "What about new documents?" → Auto Loader + incremental pipeline; new docs queryable within minutes
- "How accurate is it?" → Every answer source-cited; 7 validation layers; refuses when uncertain
- "Team size?" → Independently developed; client letter confirms "independently took ownership"
