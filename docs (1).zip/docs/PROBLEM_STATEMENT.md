# 🏥 The Provider Contract Intelligence Problem
## Why This Is One of the Most Complex Business Challenges in Healthcare Operations

---

## Executive Summary

Blue Shield of California manages **30,000+ contract documents** spanning **1,700+ provider contract folders**, covering **900+ unique healthcare provider entities** across the state. These documents represent approximately **78 GB** of legal, financial, and operational content — an estimated **~1.2 million pages** of dense healthcare contractual language.

**A single analyst attempting to read and comprehend this entire corpus would require 65+ years of full-time work.**

This is not a data problem. This is a **business-critical operational crisis** hiding in plain sight.

---

## 📊 The Scale That Defies Human Capacity

| Metric | Value |
|--------|-------|
| Total Provider Contract Folders | 1,700+ |
| Total Contract Documents | 30,000+ |
| Repository Size | ~78 GB |
| Estimated Total Pages | ~1,200,000+ |
| Unique Provider Entities | 900+ |
| Providers with Multiple Contracts | 400+ |
| Average Amendments per Provider | 15.2 |
| Maximum Amendments (Single Provider) | 94 (Mercy General Hospital) |
| Highest Document Version Found | v31 (Sharp Memorial Hospital) |
| Providers with Amendment Numbering Resets | 200+ |
| Thorough Legal Review Time | ~194,000 hours (65+ YEARS) |
| Even Quick Scan Time | ~58,000 hours (28+ YEARS) |

---

## 🔍 What Are These Documents?

These are **legally binding provider contracts** between Blue Shield of California and healthcare providers (hospitals, medical groups, IPAs) across the state and neighboring regions. They contain:

### Base Agreements
- **Fee-For-Service Hospital Agreements** — defining reimbursement rates, service categories, and payment terms
- **Provider Participation Agreements** — outlining network inclusion terms, credentialing requirements
- **IPA/Medical Group Contracts** — governing capitation, risk-sharing, and delegated responsibilities

### Amendments (The Real Complexity)
- **Numbered Amendments** (First through Twenty-Second+) — modifying specific clauses, rates, or terms
- **Legally Required Amendments (LRA)** — mandated by CMS/regulatory changes (e.g., ICD-9 to ICD-10 transitions)
- **Counter-Mark Amendments (CM)** — counter-signed versions with provider modifications
- **Addendums** — supplemental terms adding new services, facilities, or populations

### What's Inside Each Document
- Reimbursement rate schedules and fee tables
- Service category definitions and code mappings
- Term and termination clauses with effective dates
- Regulatory compliance language
- Network adequacy requirements
- Claims submission and payment timelines
- Quality metrics and performance standards
- Dispute resolution procedures
- Carve-out and exclusion lists

---

## 🌀 The Layers of Complexity

### 1. Version Chaos Within Single Documents

A single amendment can have **up to 31 versions** (Sharp Memorial Hospital's Base Agreement). Each version may represent:
- A draft vs. executed copy
- A redlined vs. clean version
- A provider-returned markup vs. Blue Shield's original
- A superseded version that should no longer apply

**The danger:** Which version is the legally binding, currently effective one? An analyst looking at `BaseAgmtRenew_v3.pdf` vs `BaseAgmtRenew_v8.pdf` vs `BaseAgmtRenew_v11.pdf` has no immediate way to know which governs the relationship TODAY.

### 2. Amendment Stacking Without Consolidation

Cedars-Sinai Medical Center alone has **34 documents**: 1 Base Agreement followed by **21 sequential amendments** (First through Twenty-First), many with multiple versions. To understand the *current* contractual state:
- You must read the base agreement
- Then layer ALL 21 amendments on top, in order
- Determine which clauses each amendment supersedes
- Account for amendments that modify PREVIOUS amendments
- Identify which amendment versions are executed vs. draft

**There is no single "current state" document.** The truth is scattered across 34 files.

### 3. Amendment Numbering Resets (Multiple Contract Lifecycles)

**200+ providers** have amendment numbering that RESETS — meaning they have multiple "First Amendment" files. This happens because:
- A contract expired and was renewed (new base agreement, amendments start over)
- Multiple contract types exist simultaneously (e.g., inpatient vs. outpatient)
- Different lines of business have separate agreements

**Example:** UCSD Medical Center has **9 different "First Amendment" files** across different contract IDs. An analyst asking "What does the First Amendment say?" gets 9 different answers depending on which contract lifecycle they're looking at.

### 4. The Same Provider, Multiple Identities

A single hospital system can appear under **multiple folder names** with different contract IDs:
- **Kindred Hospital San Diego** — 9 separate contract folders
- **Sutter Roseville Medical Center** — 8 separate contract folders  
- **Enloe Rehabilitation Center** — 7 separate contract folders
- **County of Los Angeles (Dept. of Health Services)** — 6 separate contract folders
- **400+ providers** with at least 2 separate contract identities in the system

**The danger:** An analyst researching "What's our contract with Kindred San Diego?" must know which of the 9 contracts applies to the specific service line, time period, and facility in question.

### 5. Counter-Mark (CM) vs. Standard Amendments

**4,200+ amendments** carry the "CM" suffix, indicating counter-signed or counter-marked versions where the provider has made modifications to Blue Shield's proposed terms. These co-exist alongside **15,500+ standard amendments**.

**The danger:** A CM version may contain materially different terms than the standard version. If an analyst references the wrong one, they may be operating under terms the provider never agreed to — or terms Blue Shield never intended to offer.

### 6. Mixed Document Formats

| Format | Count | Challenge |
|--------|-------|-----------|
| PDF | 29,500+ | Many are scanned images, not searchable text |
| DOCX | 400+ | Editable — may contain tracked changes, comments |
| XLSM | 50+ | Macro-enabled spreadsheets with rate tables |
| XLSX | 30+ | Static rate/fee schedules |
| DOC | 20+ | Legacy format compatibility issues |

Scanned PDFs require OCR to extract information. DOCX files may have hidden tracked changes that reveal negotiation history but confuse the "final" terms.

### 7. Temporal Ambiguity — What's Active NOW?

Contracts have:
- **Original effective dates** buried in base agreements
- **Amendment effective dates** that may be retroactive
- **Term and auto-renewal clauses** that extend without new documents
- **Termination provisions** that may have been triggered without a separate document
- **Sunset clauses** within amendments that expire certain provisions on specific dates

**There is no timestamp, status flag, or metadata reliably indicating which documents are currently in effect.**

---

## 💥 What Goes Wrong When Information Is Inferred Incorrectly

### Financial Impact

| Risk | Consequence |
|------|-------------|
| **Overpayment to Providers** | Applying outdated (higher) rates from a superseded amendment — potentially millions annually across 900+ providers |
| **Underpayment Claims** | Provider disputes when Blue Shield applies wrong rate; leads to arbitration costs, interest penalties, relationship damage |
| **Missed Rate Escalators** | Amendments often include annual escalation clauses; missing these means sudden large retroactive adjustments |
| **Incorrect Capitation Calculations** | For medical groups/IPAs, wrong cap rates cascade into incorrect risk pool settlements |

### Regulatory & Compliance Risk

| Risk | Consequence |
|------|-------------|
| **Network Adequacy Violations** | If terminated providers are treated as active (or vice versa), network filings with DMHC/CDI are inaccurate |
| **CMS Audit Failures** | Medicare Advantage contracts require documented compliance; inability to produce current terms = audit findings |
| **Member Misdirection** | Members sent to providers whose contract terms don't cover their plan type |
| **Regulatory Penalties** | Knox-Keene Act violations for operating outside contracted terms |

### Operational Paralysis

| Risk | Consequence |
|------|-------------|
| **Claims Processing Delays** | Claims staff unable to quickly verify correct reimbursement rates; adjudication backlogs grow |
| **Provider Dispute Resolution** | Months of back-and-forth because both parties reference different versions of the same amendment |
| **Contracting Team Bottleneck** | New amendments can't be drafted without understanding current state; single-person dependency risk |
| **Onboarding Failure** | New analysts take 6-12 months to become productive because institutional knowledge lives in people's heads, not systems |

### Strategic Business Impact

| Risk | Consequence |
|------|-------------|
| **Renegotiation Disadvantage** | Without clear understanding of current terms, Blue Shield enters renegotiations blind |
| **Missed Termination Windows** | Auto-renewal clauses activate because nobody tracked the opt-out deadline |
| **Duplicate Contracting** | New agreements created for providers who already have active contracts under different IDs |
| **M&A Integration Failures** | When hospital systems merge/acquire, contract mapping becomes impossible |

---

## 🔬 Deep Dive: The Most Complex Provider — Mercy General Hospital

> **109 files. 66 sub-contract IDs. 4 separate base agreements. 94 amendments. 256.3 MB. One single provider.**

Mercy General Hospital represents the ultimate stress test for any contract management approach. Here is the full anatomy of this contractual labyrinth:

### The Contract Lifecycle Map

```
📁 129131573_Mercy_General_Hospital/ (109 files, 256.3 MB)
│
├── 🟢 CONTRACT LIFECYCLE #1 (Original — ID: 129509721)
│   ├── BaseAgmtRenew_v1.pdf (30 MB!)  ← The foundational agreement
│   ├── BaseAgmtRenew_v2.pdf (404 KB)  ← What changed? Why 30MB → 400KB?
│   ├── BaseAgmtRenew_v3.pdf (232 KB)
│   ├── BaseAgmtRenew_v4.pdf (192 KB)
│   ├── BaseAgmtRenew_v5.pdf (3.3 MB)
│   ├── SixthAmendCM (ID: 130668526)    ← Amendments start at 6th?! Where are 1-5?
│   ├── SeventhAmendCM (ID: 130860994)
│   ├── EighthAmend (ID: 132860027, 2 versions)
│   ├── NinthAmend (ID: 165058226, 2 versions)
│   ├── TenthAmend (ID: 169277299)
│   ├── EleventhAmend (ID: 164079458, 2 versions)
│   ├── TwelfthAmendCM (ID: 162179414)
│   ├── ThirteenthAmendCM (ID: 188337050)
│   └── 14AmendCM (ID: 220680332)       ← NUMERIC naming! Not "Fourteenth"!
│
├── 🔵 CONTRACT LIFECYCLE #2 (Renewal — ID: 230097388)
│   ├── BaseAgmtRenew_v1.pdf (10.3 MB)
│   ├── BaseAgmtRenew_v2.pdf (10.6 MB)
│   ├── SecondAmend (ID: 237468718, 2 versions)
│   ├── ThirdAmendCM (ID: 251684703)
│   ├── FourthAmend (ID: 257909324, 2 versions)
│   ├── FifthAmendCM (ID: 277794340, 2 versions)
│   ├── SixthAmend (ID: 281959081, 2 versions)
│   ├── SeventhAmend (ID: 302336100, 2 versions)
│   ├── EighthAmendCM (ID: 306839090)
│   ├── NinthAmend (ID: 322999456, 2 versions)
│   ├── TenthAmend (ID: 333611398, 2 versions)
│   ├── EleventhAmendCM (ID: 340806946)
│   ├── TwelfthAmend (ID: 369204385, 2 versions)
│   ├── ThirteenthAmend (ID: 369132254, 2 versions)
│   ├── ThirteenthAmendCM (ID: 370184997)   ← BOTH CM and non-CM Thirteenth!
│   ├── FourteenthAmend (ID: 376099855, 2 versions)
│   ├── FifthteenthAmend (ID: 389740738)    ← MISSPELLED! "Fifthteenth"
│   ├── SixteenthAmend (ID: 398627036)
│   ├── SeventeenthAmend (ID: 401519395, 2 versions)
│   ├── EighteenthAmendCM (ID: 417402295)
│   ├── NineteenthAmend (ID: 447224810, 2 versions)
│   ├── TwentiethAmend (ID: 448345205, 2 versions)
│   ├── TwentyFirstAmendCM (ID: 454812192)
│   ├── TwentySecondAmend (ID: 465586456, 2 versions)
│   ├── TwentyThirdAmend (ID: 465594546, 2 versions)
│   ├── TwentyFourthAmend (ID: 485568466)
│   ├── TwentyFifthAmend (ID: 489504198, 2 versions)
│   └── TwentySixthAmendCM (ID: 509170233)  ← 26 amendments deep!
│
├── 🟣 CONTRACT LIFECYCLE #3 (Parallel — ID: 230136954)
│   ├── BaseAgmtRenew_v1.pdf (8.5 MB)
│   ├── BaseAgmtRenew_v2.pdf (17.6 MB)  ← Version doubled in size
│   ├── SecondAmend (ID: 237511458, 2 versions)
│   ├── ThirdAmendCM (ID: 251700080)
│   ├── FourthAmend (ID: 257937016, 3 versions!)  ← 3 versions of 1 amendment
│   ├── FifthAmendCM (ID: 277814798, 3 versions!)
│   ├── SixthAmend (ID: 281974353, 2 versions)
│   ├── SeventhAmend (ID: 302384620, 2 versions)
│   ├── EighthAmendCM (ID: 306886303)
│   ├── NinthAmend (ID: 323050753, 2 versions)
│   ├── TenthAmend (ID: 333643721, 2 versions)
│   ├── EleventhAmendCM (ID: 340834050)
│   ├── ThirteenthAmendCM (ID: 370211598)
│   ├── FourteenthAmend (ID: 376233752, 2 versions)
│   ├── FifthteenthAmend (ID: 389995504, 2 versions)
│   ├── SixteenthAmend (ID: 398687010)
│   ├── SeventeenthAmend (ID: 403792368, 2 versions)
│   ├── EighteenthAmendCM (ID: 417439859)
│   ├── NineteenthAmend (ID: 447285482, 2 versions)
│   ├── TwentiethAmend (ID: 448440814, 2 versions)
│   ├── TwentyFirstAmendCM (ID: 454886156)
│   ├── TwentySecondAmend (ID: 466344249, 2 versions)
│   ├── TwentythirdAmend (ID: 485425915)     ← DIFFERENT CASING! "Twenty-t-hird"
│   ├── TwentyFourthAmend (ID: 489598195, 2 versions)
│   └── TwentyFifthAmendCM (ID: 509136225)
│
├── 🟠 CONTRACT LIFECYCLE #4 (Another Base — ID: 130908913)
│   └── BaseAgmtRenew_v1.pdf (5.3 MB)   ← Standalone? Related to what?
│
├── 📎 SPECIAL DOCUMENTS
│   ├── FirstAddendum (ID: 285991964, 2 versions)
│   ├── BaseAddendumAddendum (ID: 319547778)  ← An addendum TO an addendum?!
│   ├── BaseAddendumAddendum (ID: 319550668)  ← TWO of them?!
│   └── SettlementAgmt (ID: 427132552)        ← A LEGAL DISPUTE was settled!
│
└── 🚨 TOTAL CHAOS INDICATORS:
    ├── "14AmendCM" (numeric) vs "FourteenthAmend" (word) — same amendment?
    ├── "FifthteenthAmend" — MISSPELLED in official legal documents
    ├── "TwentythirdAmend" vs "TwentyThirdAmend" — casing inconsistency
    ├── Two parallel amendment chains running simultaneously (Lifecycle #2 & #3)
    ├── Amendment numbering starts at 6th in Lifecycle #1 (where are 1-5?)
    └── Settlement Agreement suggests past dispute over contract interpretation
```

### Why This Single Provider Is Nightmare Fuel

| Question | Difficulty |
|----------|------------|
| "What's our current base agreement with Mercy General?" | Which of 4 base agreements? Which version (up to 5)? |
| "What rate applies to cardiac DRGs?" | Must traverse 26+ amendments to find latest applicable rate |
| "Is Amendment 13 the CM or non-CM version?" | Both exist. Under two different contract IDs. For two different lifecycles. |
| "What does the Fifteenth Amendment say?" | It's misspelled as "FifthteenthAmend" — good luck searching |
| "Were there disputes about this contract?" | Yes — there's a Settlement Agreement. What did it resolve? What terms changed? |
| "Which amendments are currently active?" | Requires determining which of 4 lifecycles is active, then which amendments aren't superseded |

### The Mathematical Impossibility

To determine the **current contractual state** of Mercy General Hospital:
- An analyst must identify the correct lifecycle (4 options)
- Read the correct base agreement version (up to 5 versions)
- Layer up to 26 sequential amendments
- For each amendment, determine if CM or standard version was executed
- Cross-reference the Settlement Agreement for any overriding terms
- Check each amendment's effective date against today
- Verify no subsequent amendment supersedes earlier ones

**Possible interpretation paths: 4 × 5 × 26 × 2 = 1,040+ combinatorial paths through the documents.**

*And this is just ONE of 1,700+ providers.*

---

## 🎯 The Human Reality

Imagine you're a **Provider Contract Analyst** at Blue Shield of California. A claims dispute arrives:

> *"Mercy General Hospital says we owe them $2.3M more than we paid for Q3 cardiac procedures. They claim Amendment 14 updated the DRG weights. We need to verify."*

Here's what you face:

1. **Which Mercy General Hospital?** There are 5 separate contract folders for this provider.
2. **Which contract applies?** You need to identify the correct contract ID for the service line and date range.
3. **Find the 14th Amendment.** But wait — amendment numbering reset with the 2018 renewal. Is it the 14th amendment of the original contract or the renewed one?
4. **Which version?** The 14th Amendment has v1 and v2. One is the draft, one is executed. Or is it one is Blue Shield's and one is the CM (counter-mark)?
5. **Read it in context.** The 14th Amendment references "Exhibit C as modified by the Eighth Amendment." Now you need to find and read the 8th Amendment too.
6. **Verify effective date.** Does this amendment even apply to Q3? Maybe it was executed in Q2 but has a future effective date.
7. **Check for supersession.** Has any subsequent amendment (15th, 16th, 17th...) modified or reversed the rate change from the 14th?

**This single verification could take DAYS.** Now multiply by hundreds of disputes per year, across 900+ providers.

---

## 📁 The File Structure That Amplifies Confusion

```
Provider_Contracts/
├── 129088335_Cedarssinai_Medical_Center/       ← 34 files, 21 amendments
│   ├── ..._BaseAgmtRenew_v1.pdf                ← Original base (which version is current?)
│   ├── ..._SecondAmend_v1.pdf                  ← Draft or executed?
│   ├── ..._SecondAmend_v2.pdf                  ← Counter-mark or final?
│   ├── ..._FifthAmendCM_v1.pdf                 ← CM = Counter-Mark (provider's version)
│   ├── ..._FifthAmendCM_v2.pdf                 ← Different from non-CM Fifth?
│   ├── ..._TwentyFirstAmend_v1.pdf             ← Latest? Or is there a 22nd pending?
│   └── ..._TwentyFirstAmend_v2.pdf
│
├── 129131573_Mercy_General_Hospital/           ← 109 files! 94 amendments!
│   ├── ..._BaseAgmtRenew_v1.pdf through v5     ← 5 versions of base agreement
│   ├── ..._SixthAmendCM_v1.pdf                 ← Multiple contract lifecycles
│   ├── ..._230097388_BaseAgmtRenew_v1.pdf      ← SECOND base agreement (renewal)
│   ├── ..._230136954_BaseAgmtRenew_v1.pdf      ← THIRD base agreement?!
│   ├── ..._SecondAmend_v1.pdf (ID: 237468718)  ← Which "Second Amendment"?
│   └── ..._SecondAmend_v1.pdf (ID: 237511458)  ← Different Second Amendment!
│
├── 129109176_Stanford_Health_Care/             ← 30 files, 17 amendments + special types
│   ├── ..._BaseAgmtRenew_v1.pdf through v11    ← 11 versions of ONE base agreement!
│   ├── ..._FifteenthAmendCM_v1.pdf             ← Counter-mark
│   ├── ..._SixteenthAmendCM_v1.pdf             ← Counter-mark
│   ├── ..._ONEAmendCM_v1.pdf                   ← What is "ONE" Amend? New naming!
│   └── ..._SeventeenthAmendCM_v1.pdf
│
└── [1,697 more provider folders...]
```

---

## 🚨 Why This Problem MUST Be Solved With AI

### Traditional Approaches Have Failed

| Approach | Why It Fails |
|----------|-------------|
| **Hire more analysts** | 65+ years of reading time; turnover erases institutional knowledge |
| **Build a spreadsheet tracker** | Manually maintained → immediately outdated; doesn't capture clause-level detail |
| **Contract management software** | Requires manual tagging of 30,000+ documents; same human bottleneck |
| **Ask the contracting team** | Single points of failure; retirement/turnover = catastrophic knowledge loss |
| **Consolidate into single documents** | Legal complexity of re-drafting 1,700+ contracts; cost prohibitive |

### What AI-Powered Contract Intelligence Delivers

1. **Instant Contract State Resolution** — "What are our current terms with Provider X?" answered in seconds, not days
2. **Amendment Chain Traversal** — Automatically traces amendment supersession to derive current effective terms
3. **Version Disambiguation** — Identifies executed vs. draft, CM vs. standard, active vs. expired
4. **Cross-Provider Intelligence** — "Which providers have similar rate structures?" across all 900+ entities
5. **Proactive Risk Detection** — Alerts for approaching termination windows, expiring amendments, rate escalator triggers
6. **Dispute Resolution Acceleration** — Instant evidence retrieval with citation to specific document, page, and clause
7. **Regulatory Compliance Assurance** — Real-time verification that network status matches contractual reality

---

## 🎪 The Competitive Edge

This isn't just a document management problem. This is a problem where:

- **The data is massive** — 78+ GB, 1.2M+ pages
- **The structure is chaotic** — No standardization across 20+ years of contracting
- **The stakes are existential** — Wrong answers = millions in financial exposure + regulatory risk
- **The domain is specialized** — Healthcare contract law + medical coding + regulatory compliance
- **The relationships are complex** — Amendments reference amendments that reference base agreements that have been renewed
- **The truth is emergent** — No single document tells you the current state; it must be COMPUTED from the full chain

**This is not a problem that can be solved by keyword search, simple RAG, or basic document Q&A. It requires deep understanding of contract law semantics, temporal reasoning, cross-document relationship mapping, and domain-specific intelligence.**

---

## 📐 The Numbers That Matter

```
1,700+    contract folders to navigate
30,000+   documents to parse and understand
~78 GB    of dense legal and financial content
~1,200,000  pages of contractual language
19,700+   amendments that modify base terms
400+      providers with MULTIPLE parallel contracts
200+      providers where amendment numbering RESETS
94        maximum amendments on a SINGLE provider
31        maximum versions of a SINGLE document
9         maximum separate contracts for ONE provider
65+       YEARS of full-time work to manually review everything
$Billions in annual provider payments governed by these documents
```

---

## The Bottom Line

> **Every day that an analyst cannot instantly and accurately determine the current contractual state of a provider relationship, Blue Shield of California is exposed to financial leakage, regulatory non-compliance, operational inefficiency, and strategic blindness.**

> **This project — Contract Intelligence — transforms an impossible 65-year human task into an intelligent, queryable, always-current knowledge system. It is not an incremental improvement. It is the difference between flying blind and having complete visibility into $Billions in provider payment obligations.**

---

*Document generated from live analysis of `/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts/`*  
*Last updated: August 2026*