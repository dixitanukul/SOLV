# 🎙️ Presentation Speech Script
## Contract Intelligence Platform — 12-Minute Panel Presentation (22 Slides)

---

## Slide 1: The $Billion Question No One Could Answer
**[~20 seconds]**

Good morning everyone.

Blue Shield of California manages billions of dollars in provider contract obligations. The information governing those billions — the rates, the clauses, the terms — lives inside over 10,500 contract documents that no human team can fully read, let alone comprehend.

Today I'm going to show you how we solved that — and the technology stack that makes it possible.

---

## Slide 2: The Contract Landscape
**[~25 seconds]**

Over 10,500 documents. 27 gigabytes. 408,000 pages of dense legal and financial language. 328 unique healthcare providers. Nearly 7,000 amendments tracked.

If one analyst tried to thoroughly review all of this — just read it — it would take over 30 years of full-time work.

And these aren't blog posts — they're legally binding contracts that determine how billions of dollars in healthcare payments are made every single day.

---

## Slide 3: The 7 Layers of Complexity
**[~25 seconds]**

But it's not just volume — it's complexity. 7 distinct layers of chaos.

31 versions of one document. 21 amendments stacked on a base agreement. Numbering that resets when contracts renew — 71 providers have multiple "First Amendment" files. Counter-marked versions where the provider changed the legal terms. 10,372 PDFs — many scanned images, not searchable text.

And the critical point: there is NO metadata, NO flag, NO system anywhere that tells you which documents are actually in effect right now.

---

## Slide 4: The Human Reality
**[~25 seconds]**

9 AM — the Claims team asks: "What's the rate for Stanford?" An analyst opens the shared drive. Finds 30 files. Opens a 72-page PDF. Finds a rate — "subject to amendment." Reads amendments. Two versions exist. Calls the contracting manager. Voicemail.

3 hours. 1 phone call. Zero audit trail. Still not sure it's right. Multiply that by 15 queries a day across 7 teams.

---

## Slide 5: The Cost of Inaction
**[~20 seconds]**

This isn't just inconvenience — it's financial risk. Claims paid on superseded rates. Termination windows missed. CMS audits finding non-compliance.

Total risk exposure: $5 to $15 million per year. And the alternatives? Half a million a year to hire analysts who can't scale. Or $2 to $4 million for a vendor platform that still won't understand healthcare contracts.

---

## Slide 6: Mercy General Hospital
**[~20 seconds]**

One provider. 109 files. 4 separate base agreements. 66 sub-contract IDs. Two parallel amendment chains. A misspelled amendment. An addendum to an addendum. Over 1,000 possible interpretation paths.

This is what the system has to solve. Not for one provider — for all 328.

---

## Slide 7: The Vision
**[~15 seconds]**

The client's stated goal: "Digitize contract information once, reuse it across Utilization Management, Care Management, Provider Relations, Analytics, and other downstream functions."

Digitize once. Reuse everywhere. Trust completely. That's what CIP delivers. Let me show you the technology.

---

## Slide 8: Databricks Pipeline Architecture
**[~35 seconds]**

The foundation is a 16-stage pipeline built entirely on Databricks.

Auto Loader detects new files incrementally — no manual triggers. Apache Spark distributes OCR processing across the cluster in parallel. The Foundation Model API calls Claude Sonnet 4.5 with a 17-rule extraction prompt for every document — rates, clauses, provisions, all structured.

Everything lands in Delta Lake — 45 managed tables with ACID transactions, time travel, and schema enforcement. The pipeline uses incremental MERGE with exactly-once semantics — no duplicates, no reprocessing.

And this is fully scalable. The same pipeline handles 10 documents or 10,000. Blue Shield of Kansas will use the identical infrastructure with different parameters.

---

## Slide 9: Unity Catalog Governance & Data Model
**[~30 seconds]**

Everything lives under Unity Catalog — catalog `dev_adb`, schema `cip_v5`. Full lineage, access control, and audit trail built in.

45 Delta tables in a star schema: rates, clauses, stop-loss, carve-outs, compliance, definitions, provider profiles.

But the governance layer is what makes this enterprise-ready. Three dedicated tables: `tbl_cip_gov_llm_audit` logs every single LLM call — tokens, cost, latency, model version. `tbl_cip_gov_prompt_registry` versions every prompt for A/B testing and rollback. `tbl_cip_access_log` tracks who queried what and when.

Plus 5 quality gates that catch errors before they propagate — OCR quality, JSON schema validation, data integrity, state consistency, retrieval quality.

---

## Slide 10: RAG Architecture & Vector Search
**[~35 seconds]**

This is NOT generic RAG — not just "embed and retrieve." It's a 4-channel hybrid retrieval architecture.

Channel 1: Semantic search using Databricks GTE-Large embeddings — 1024 dimensions — against a Vector Search index of legal passage units.

Channel 2: Lexical search via BM25 for exact keyword matching.

Channel 3: Metadata filtering — provider name, contract type, date range, and critically, the `current_effective` flag — so you never see superseded data.

Channel 4: Structural retrieval — amendment chain traversal and supersession graph navigation.

All four channels fuse via Reciprocal Rank Fusion, then the top passages go to the LLM.

And the chunking is domain-specific — legal units like clauses, sections, and exhibits. Not arbitrary 512-token blocks. That's why the retrieval actually works on dense legal language.

---

## Slide 11: Application Architecture & Tech Stack
**[~25 seconds]**

The full stack: React 18 with TypeScript and Tailwind on the frontend. Server-Sent Events for real-time streaming. FastAPI backend with 9 endpoints. A ReAct agent loop with budget controls — max 10 steps, $15 ceiling, 120-second timeout.

30+ specialized tools — rate queries, clause checks, amendment chains, financial analysis, compliance queries, chart generation, data export.

LLM: Claude Sonnet 4.5 via Databricks Foundation Model API. Embeddings: GTE-Large via Databricks. Search: Databricks Vector Search. Storage: 45 Delta tables. Deployment: Databricks App — containerized, production-grade.

The entire platform runs on Databricks. End to end.

---

## Slide 12: LLM-as-Judge & 7-Layer Trust
**[~30 seconds]**

This is the key differentiator. 7 layers of validation — and 5 of them cost zero because they're deterministic.

Layer 1: routing validation with 6 override rules. Layer 2: retrieval quality scoring. Layer 3: a hallucination guard — 5 checks on every answer at zero LLM cost. Layer 4: an answer validator called "Prove It" — if the LLM claims data doesn't exist, we run a SQL check to verify.

Layer 5: grounding enforcement — the system refuses to answer rather than guess. Layer 6: citation verification — every claim traced to document and page.

And Layer 7: LLM-as-Judge. A separate LLM evaluation that scores answer completeness against the original question. Did we address every sub-question? Is the confidence warranted?

Total validation cost per query: about half a cent. No other project in this competition has even one of these layers. We have seven.

---

## Slide 13: The Range of Questions
**[~20 seconds]**

Rate lookups. Clause existence checks. Cross-provider comparisons. Historical amendment tracing. Portfolio-wide analysis across all 328 providers. Compliance risk detection. Multi-hop questions combining rates, clauses, and temporal logic.

Simple questions: 8 to 12 seconds. Complex multi-hop: 30 to 60 seconds. All cited. All with confidence scores. Per-query cost: about one cent.

---

## Slide 14: Before vs. After
**[~30 seconds]**

The transformation. Before: 3 hours, a phone call, no audit trail, "I think this is right."

After: 12 seconds. Full citation — document name, page number, section reference. Confidence: HIGH. "The rate is $2,847 per day per the 15th Amendment CM, page 4, section 3.2(b). This supersedes $2,614 per day from the 11th Amendment."

900 times faster. With evidence. With confidence. At a cost of one cent per query.

---

## Slide 15: Who It Serves
**[~20 seconds]**

Seven business units served by a single platform. Claims gets instant rate verification. Provider Relations gets full scorecards before negotiations. Compliance gets provenance trails on demand. Analytics gets structured data where there was none. One platform. Seven teams. Zero additional cost per user.

---

## Slide 16: $690K–$1M Validated Savings
**[~25 seconds]**

$690,000 to $1 million in annual value — written by the client's own C-suite leadership in a formal recognition letter. Not self-reported.

$308K in research savings. $54K in onboarding. $179K in renewal efficiency. Up to $500K in avoided vendor licensing — because CIP eliminates the need for platforms like Icertis or Agiloft.

Every dollar validated by the client.

---

## Slide 17: Revenue Generation
**[~25 seconds]**

This generates revenue. 35 independent Blue Shield companies face the identical contract chaos. Blue Shield of Kansas is the first pilot.

Year 1: $400K to $750K. Year 3: $2.5 to $5 million. Year 5: $5 to $10 million.

This isn't a cost center. It's a product — and it's already selling.

---

## Slide 18: 5-Year Value — $31.7M
**[~20 seconds]**

Five-year total: $31.7 million. $4.7M in savings. $17M in licensing revenue. $10M in risk mitigation.

Development cost: ~$250K. Year 1 value: $3.35M. ROI: 13x. Payback: under 3 months.

---

## Slide 19: Delivery Timeline
**[~20 seconds]**

Five months. April to August 2026. Every month a major subsystem shipped. Pipeline. State engine. Vector Search. Application. Productization.

Data engineering, LLM prompt engineering, full-stack web development, trust architecture — all delivered end-to-end in 5 months.

---

## Slide 20: Hardest Problems Solved
**[~20 seconds]**

Three problems with no existing solution.

Supersession: Which of 109 documents governs today? Built a DAG-based state engine.

Grounding: LLMs hallucinate on financial data. Built 7 trust layers with zero-cost validation — including catching a production bug where `$27,748` versus `27748.0` broke every confidence score.

Routing: "Does Stanford have per diem rates?" could be 3 different question types. Built 6 override rules that correct misclassification before the wrong tool fires.

These problems only exist because the domain is this hard — healthcare contract law at scale.

---

## Slide 21: Roadmap
**[~15 seconds]**

Q4 2026: Proactive expiration alerts and Blue Shield Kansas goes live. Q1 2027: cross-plan benchmarking and automated renewal briefings. By 2028: 10 to 15 licensees and expansion to commercial payers.

Not a completed project. A growing product with a multi-year revenue trajectory.

---

## Slide 22: The Bottom Line
**[~15 seconds]**

10,500 documents. 16-stage Databricks pipeline. 45 Delta tables. RAG with Vector Search. LLM-as-Judge with 7 trust layers.

$690K to $1M in client-validated savings. Revenue across the Blue Shield network.

Concept to production in 5 months. Live users. Revenue-generating.

Not a project — a product. Thank you.

---

## TIMING SUMMARY

| Section | Slides | Time |
|---------|--------|------|
| Problem & Stakes | 1–6 | ~2:15 |
| Technology & Solution | 7–14 | ~3:50 |
| Impact & Revenue | 15–18 | ~1:30 |
| Ownership & Close | 19–22 | ~1:10 |
| **Buffer** | — | ~1:15 |
| **TOTAL** | **22 slides** | **~10:00 speaking + 2:00 buffer = 12:00** |

---

## DELIVERY TIPS

- **Slide 8 (Pipeline):** Slow down on "scalable" — this is a tech credibility moment.
- **Slide 10 (RAG):** This is your technical differentiator. Emphasize "NOT generic RAG."
- **Slide 12 (LLM-as-Judge):** Pause after "half a cent." Let judges absorb the cost-efficiency.
- **Slide 14 (Before/After):** This is your applause moment. Pause after "12 seconds."
- **Slide 22 (Close):** Land firmly. "Not a project — a product. Thank you." Full stop.
- **If you go long:** Cut Slide 21 (Roadmap) — mention it in one sentence on the closing.
- **If asked about tech in Q&A:** You've already covered it; point back to Slides 8–12.
